---
title: "Quantum Foundations — Cycles 8–11 Report"
subtitle: "Sub-Topics 7–10: Path Integrals, Open Systems, Hydrogen & Helium, Quantum Information"
date: "2026-03-20"
geometry: margin=1in
---

# Quantum Foundations — Cycles 8–11

## Overview

Cycles 8–11 completed the remaining four sub-topics of the quantum foundations exploration, bringing the project to ten sub-topics with ten libraries, nine exploration scripts, and ten test suites. The deliverables are:

- **Sub-Topic 7: Path Integral Formulation** — library (248 lines, 14 functions), exploration (490 lines, 7 parts), tests (22/22 pass)
- **Sub-Topic 8: Open Quantum Systems** — library (266 lines, 15 functions), exploration (586 lines, 6 parts), tests (22/22 pass)
- **Sub-Topic 9: 3D Hydrogen & Helium** — library (279 lines, 16 functions), exploration (290 lines, 9 parts), tests (31/31 pass)
- **Sub-Topic 10: Quantum Information** — library (499 lines, 22 functions), exploration (402 lines, 9 parts), tests (30/30 pass)

An independent audit validated Sub-Topic 9 (all 8 sufficiency criteria met, 31/31 tests, no physics errors). The audit for Cycle 8 was unavailable. Total project: **267/267 tests passing** across 10 libraries with **161 public functions**.

## Cycle-to-Sub-Topic Mapping

The cycle sessions provided for this report period are:

| Cycle | Researcher | Worker | Auditor | Artifacts |
|-------|------------|--------|---------|-----------|
| 8 | 220daf3a | 723d840f | a283cb04 | Sub-Topics 7–8 (Path Integral, Open Systems) |
| 9 | d4668b00 | c730288c | 18027e50 | Sub-Topic 9 (Hydrogen & Helium) |
| 10 | c6a1110a | d36c730b | 2fa992a4 | Sub-Topic 10 (Quantum Information) |
| 11 | 3983dcfd | — | — | Research only (no worker or auditor) |

The mapping of cycles 8–9 to sub-topics 7–9 is reconstructed from file modification timestamps (path integral files are oldest, open systems next, then hydrogen/helium). Cycle 8 produced two sub-topics; its audit was unavailable. Cycle 11 had a researcher session only — no new code artifacts were produced.

## Audit Reports

### Cycle 8: Audit Unavailable

The audit agent was unavailable for Cycle 8. The guidance was to continue with the current sub-topic for re-evaluation in the next cycle.

### Cycle 9: Sub-Topic 9 (Hydrogen & Helium) — VALIDATED

The independent audit validated Sub-Topic 9 with all 8 sufficiency criteria met:

| # | Criterion | Status |
|---|-----------|--------|
| 1 | Full 3D hydrogen wavefunctions constructed and normalized | MET |
| 2 | Hydrogen expectation values match exact formulas | MET |
| 3 | Selection rules correctly discriminate allowed/forbidden | MET |
| 4 | Helium variational energy within 2% of exact | MET (1.93%) |
| 5 | Variational theorem satisfied | MET |
| 6 | Electron-electron repulsion integral verified | MET ($\Delta = 1.2 \times 10^{-7}$) |
| 7 | Hartree SCF converges and improves on independent-particle | MET (15 iterations) |
| 8 | All tests pass ($\geq$ 25) | MET (31/31) |

The audit found four informational issues (no errors): `NIntegrate` convergence warnings for 3D integrals, minor code duplication between `QVariationalEnergy` and `QHeliumTrialEnergy`, scope reduction on general variational tools (helium-specific rather than general-purpose), and cosmetic `NumberForm` rendering. None affect correctness.

The audit's cumulative table showed 9/9 sub-topics validated at the end of Cycle 9, with Sub-Topic 10 remaining.

## Sub-Topic 7: Path Integral Formulation

### Library: `lib/qm_path_integral.wls` (248 lines, 14 functions)

The Feynman path integral formulates quantum mechanics as a sum over all possible histories, each weighted by $e^{iS[\text{path}]/\hbar}$ where $S$ is the classical action. This library implements exact propagators, lattice discretizations, and semiclassical approximations.

**Exact propagators.** The library provides closed-form propagators for two exactly solvable cases:

- **`QFreeParticlePropagator[x1, x0, t]`** — The free particle propagator $K(x_1, x_0; t) = \sqrt{m/(2\pi i \hbar t)} \exp(im(x_1-x_0)^2/2\hbar t)$.

- **`QHarmonicPropagator[x1, x0, t, omega]`** — The harmonic oscillator propagator involving $\sin(\omega t)$ and quadratic terms in $(x_0, x_1)$.

**Classical actions.** Three functions compute the Hamilton principal function $S_{\text{cl}}$ for trajectories connecting two endpoints:

- **`QClassicalAction[L, x, t, {t0, t1}]`** — General action by integrating a Lagrangian along a path.
- **`QFreeParticleAction`**, **`QHarmonicAction`** — Closed-form actions for the two solvable cases.

**Lattice path integral.** The path integral is discretized on a time lattice of $N$ slices:

- **`QLatticePropagator[V, x0, x1, t, N]`** — Computes $K \approx \int \prod_k dx_k \, e^{iS_{\text{lattice}}}$ via nested numerical integration. The kinetic term is discretized as $m(\Delta x)^2/2\Delta t$ and the potential term as $V(x_k)\Delta t$.
- **`QLatticeFreeParticle`** — Lattice propagator for zero potential (exact for any $N$).
- **`QEuclideanLatticePropagator`** — Wick-rotated ($t \to -i\tau$) lattice propagator for imaginary-time calculations.

**Semiclassical approximation.** The Van Vleck–Morette formula gives the leading-order approximation to the propagator:

$$K_{\text{sc}}(x_1, x_0; t) = \sqrt{\frac{1}{2\pi i \hbar}\left|\frac{\partial^2 S_{\text{cl}}}{\partial x_1 \partial x_0}\right|} \exp\!\left(\frac{i S_{\text{cl}}}{\hbar}\right)$$

- **`QVanVleckPrefactor`** — Computes the prefactor from the mixed second derivative of the action.
- **`QSemiclassicalPropagator`** — Combines prefactor and phase.

**Thermal/Euclidean path integral.** Wick rotation connects quantum mechanics to statistical mechanics:

- **`QEuclideanPropagator`** — Imaginary-time propagator $K_E(x_1, x_0; \beta)$.
- **`QPartitionFunction`** — Thermal partition function $Z(\beta) = \int dx \, K_E(x, x; \beta)$.
- **`QThermalDensity`** — Thermal density matrix $\rho(x, x'; \beta) = K_E(x, x'; \beta)/Z$.
- **`QPropagatorSpectral`** — Spectral decomposition $K = \sum_n \psi_n(x_1)\psi_n^*(x_0) e^{-E_n t}$ for cross-validation.

The library depends on `QMSystems\`` (for energy eigenvalues in the spectral decomposition).

### Exploration: `qm_foundations_07_path_integral.wls` (490 lines, 7 parts)

| Part | Topic | Key Results |
|------|-------|-------------|
| A | Exact propagators | Free particle and harmonic oscillator propagators verified against Schrödinger equation; spectral decomposition matches |
| B | Lattice path integral | Free particle exact at any $N$; harmonic oscillator converges as $N$ increases; phasor visualization shows constructive interference near classical path |
| C | Classical limit | Semiclassical propagator exact for quadratic Lagrangians; Van Vleck prefactor reproduced |
| D | Path integral $\to$ Schrödinger | Derived Schrödinger equation from short-time expansion of propagator; Gaussian wave packet evolution verified |
| E | Euclidean path integral | Partition functions, free energy, thermal density matrices; zero-point energy to classical limit transition |
| F | Tunneling and instantons | Double-well tunneling amplitude $\Delta E \sim C e^{-S_{\text{inst}}}$; WKB validation |

### Tests: 22/22 pass

Covers: free particle propagator normalization and Schrödinger compliance, harmonic oscillator propagator, action computations, lattice convergence, semiclassical exactness for quadratic potentials, Euclidean propagator properties, and instanton/tunneling calculations.

## Sub-Topic 8: Open Quantum Systems

### Library: `lib/qm_open_systems.wls` (266 lines, 15 functions)

Real quantum systems interact with their environments. The Lindblad master equation describes the most general Markovian evolution of a density matrix that preserves complete positivity and trace:

$$\frac{d\rho}{dt} = -i[H, \rho] + \sum_k \gamma_k \left( L_k \rho L_k^\dagger - \frac{1}{2}\{L_k^\dagger L_k, \rho\} \right)$$

**Lindblad dynamics (6 functions).** The library vectorizes the density matrix ($\rho \to |\rho\rangle\!\rangle$) and constructs the Liouvillian superoperator $\mathcal{L}$ as a matrix, enabling evolution via matrix exponentiation:

- **`QVectorize`** / **`QUnvectorize`** — Convert between $n \times n$ density matrices and $n^2$-vectors.
- **`QLindbladSuperoperator[H, Ls, gammas]`** — Constructs the $n^2 \times n^2$ Liouvillian superoperator from Hamiltonian $H$ and Lindblad operators $\{L_k\}$ with rates $\{\gamma_k\}$.
- **`QLindbladEvolve[L, rho0, t]`** — Evolves $\rho_0$ to time $t$ via $|\rho(t)\rangle\!\rangle = e^{\mathcal{L}t}|\rho_0\rangle\!\rangle$.
- **`QLindbladTrack[L, rho0, times]`** — Returns $\rho(t)$ at multiple time points.
- **`QLindbladSteadyState[L]`** — Finds the steady state as the null eigenvector of $\mathcal{L}$.

**Standard noise channels (4 functions).** Pre-built Lindblad operators for common physical processes:

- **`QSpontaneousEmission[gamma]`** — Excited state decay with $L = \sqrt{\gamma}\,|0\rangle\langle 1|$.
- **`QPureDephasing[gamma]`** — Off-diagonal decay with $L = \sqrt{\gamma}\,\sigma_z/\sqrt{2}$.
- **`QThermalBath[gamma, nbar]`** — Thermalization with emission and absorption operators satisfying detailed balance.
- **`QDampedHO[gamma, nbar, nmax]`** — Damped harmonic oscillator truncated to $n_{\max}$ Fock states.

**Information measures (5 functions).** Quantum information-theoretic quantities for analyzing open system dynamics:

- **`QMutualInformation[rhoAB, dimA, dimB]`** — $I(A{:}B) = S(\rho_A) + S(\rho_B) - S(\rho_{AB})$.
- **`QConditionalEntropy[rhoAB, dimA, dimB]`** — $S(A|B) = S(\rho_{AB}) - S(\rho_B)$ (can be negative for entangled states).
- **`QRelativeEntropy[rho, sigma]`** — $S(\rho \| \sigma) = \mathrm{Tr}(\rho \log \rho - \rho \log \sigma) \geq 0$ (Klein's inequality).
- **`QChannelFidelity[rhoIn, rhoOut]`** — $F(\rho_{\text{in}}, \rho_{\text{out}}) = (\mathrm{Tr}\sqrt{\sqrt{\rho_{\text{in}}}\,\rho_{\text{out}}\sqrt{\rho_{\text{in}}}})^2$.
- **`QStinespringUnitary[KrausOps, dimE]`** — Constructs the system-environment unitary $U$ that dilates a set of Kraus operators.

### Exploration: `qm_foundations_08_open_systems.wls` (586 lines, 6 parts)

| Part | Topic | Key Results |
|------|-------|-------------|
| A | Lindblad master equation | Superoperator construction; trace preservation and hermiticity verified |
| B | Spontaneous emission and dephasing | Exponential decay $e^{-\gamma t}$; T$_1$/T$_2$ relation $T_2 \leq 2T_1$; cross-validation against Kraus operators |
| C | Thermalization | Gibbs state reached; Boltzmann population ratios verified; entropy production and second law |
| D | Damped harmonic oscillator | Fock state decay; coherent state pointer states (remain pure during decay); thermal equilibrium with geometric photon distribution |
| E | Information measures | Mutual information, conditional entropy (negative for entanglement), relative entropy, Klein's inequality, quantum data processing inequality |
| F | Stinespring dilation | Unitary dilation for amplitude damping and depolarizing channels; verification $\varepsilon(\rho) = \mathrm{Tr}_E(U|0\rangle\langle 0| \otimes \rho \, U^\dagger)$ |

Three debug scripts (`debug_open.wls`, `debug_entropy.wls`, `debug_lattice.wls`, 146 lines total) were created during development of Sub-Topics 7–8 to diagnose integration convergence and lattice discretization issues.

### Tests: 22/22 pass

Covers: superoperator construction, trace preservation, spontaneous emission dynamics, dephasing rates, thermalization to Gibbs state, damped oscillator, mutual information, conditional entropy negativity for entangled states, relative entropy (Klein's inequality), channel fidelity, and Stinespring dilation for multiple channels.

## Sub-Topic 9: 3D Hydrogen & Helium

### Library: `lib/qm_hydrogen_helium.wls` (279 lines, 16 functions)

This library treats the two foundational problems of atomic physics: the exactly solvable hydrogen atom and the simplest many-electron system, helium, which requires approximation methods.

**Hydrogen wavefunctions (6 functions).** Full 3D wavefunctions $\psi_{nlm}(r, \theta, \phi) = R_{nl}(r) Y_l^m(\theta, \phi)$:

- **`QHydrogenWF3D[n, l, m, r, theta, phi, Z]`** — Constructs the hydrogen wavefunction using associated Laguerre polynomials and spherical harmonics.
- **`QHydrogenProbDensity`** — $|\psi_{nlm}|^2$.
- **`QRadialProbability`** — $r^2 |R_{nl}(r)|^2$.
- **`QHydrogenExpectR[n, l, Z]`** — Exact formula $\langle r \rangle_{nl} = (3n^2 - l(l+1))/2Z$.
- **`QHydrogenExpectInvR[n, l, Z]`** — Exact formula $\langle 1/r \rangle_{nl} = Z/n^2$.
- **`QDegeneracy[n]`** — Returns $n^2$ (orbital) and $2n^2$ (with spin).

**Selection rules (2 functions).** Electric dipole transitions obey $\Delta l = \pm 1$, $\Delta m = 0, \pm 1$:

- **`QDipoleSelectionRule[l1, m1, l2, m2]`** — Boolean test.
- **`QDipoleMatrixElement[n1, l1, m1, n2, l2, m2, Z]`** — Factored into radial integral $\int R_1 R_2 r^3 dr$ and angular Gaunt integral $\int Y_1^* Y_1^0 Y_2 \, d\Omega$.

**Helium approximation methods (8 functions).** Three levels of increasing sophistication:

1. **Independent-particle model**: `QHeliumIndependent[Z]` — Ignores $1/r_{12}$ repulsion; gives $E = -Z^2 = -4.0$ Ha (38% error).

2. **Variational method**: `QHeliumTrialEnergy[Zeff, Z]`, `QHeliumVariational[Z]` — Uses screened hydrogenic trial function with $Z_{\text{eff}}$ as variational parameter. Minimization yields $Z_{\text{eff}} = 27/16$, giving $E = -2.8477$ Ha (1.93% error vs exact $-2.9037$ Ha).

3. **Hartree SCF**: `QHartreeIteration[Z, nGrid, rMax, nIter, mix]` — Self-consistent field on a radial grid (default 400 points). Each electron moves in the mean field of the other. Converges in approximately 15 iterations to $E = -2.8534$ Ha (1.73% error). The implementation uses cumulative sums for $O(N)$ Hartree potential construction and linear mixing for convergence stabilization.

- **`QHeliumRepulsionIntegral`** / **`QHeliumRepulsionNumerical`** — Analytical ($5Z_{\text{eff}}/8$) and numerical computation of $\langle 1/r_{12} \rangle$ for cross-validation.
- **`QVariationalEnergy`** / **`QVariationalMinimize`** — Helium-specific variational tools (the audit notes these are specialized rather than general-purpose, which is a reasonable simplification).

### Exploration: `qm_foundations_09_hydrogen_helium.wls` (290 lines, 9 parts)

| Part | Topic | Key Results |
|------|-------|-------------|
| A | 3D wavefunctions | Normalization to $10^{-10}$; orthogonality verified; $\langle r \rangle$, $\langle 1/r \rangle$ match exact formulas |
| B | Orbital shapes | Radial nodes $= n-l-1$; angular nodes $= l$; $r_{\max} = n^2 a_0$ for highest-$l$ orbitals |
| C | Selection rules | 3 allowed transitions ($|\langle d \rangle| > 0$), 3 forbidden ($|\langle d \rangle| = 0$ exactly); $1s \to 2p$ matrix element $= 0.7449\,a_0$ matches analytical $256\sqrt{2}/729$ |
| D | Degeneracy | $n^2$ states per shell, $2n^2$ with spin, verified for $n = 1$–$4$ |
| E–F | Helium: independent $\to$ variational | Error drops from 38% to 1.93%; optimal $Z_{\text{eff}} = 27/16$ |
| G | Repulsion integral | Analytical vs numerical agreement to $1.2 \times 10^{-7}$ |
| H | Hartree SCF | Convergence in 15 iterations; $E = -2.8534$ Ha |
| I | Method comparison | Independent ($-4.0$) $>$ Variational ($-2.848$) $>$ Hartree ($-2.853$) $>$ Exact ($-2.904$) |

### Tests: 31/31 pass

Ten test sections covering normalization, orthogonality, expectation values, degeneracy, selection rules, independent-particle model, variational method, repulsion integral, Hartree SCF convergence, and variational theorem verification.

## Sub-Topic 10: Quantum Information

### Library: `lib/qm_information.wls` (499 lines, 22 functions)

The largest library in the project, implementing quantum computing primitives and information protocols.

**Quantum gates (9 functions).** Standard single- and multi-qubit gates:

- **Single-qubit**: `QHadamard`, `QPhaseGate` ($S$), `QTGate` ($T = \sqrt{S}$), `QRz[theta]` (arbitrary $z$-rotation).
- **Two-qubit**: `QCNOT`, `QCZ`, `QSWAP`.
- **Three-qubit**: `QToffoli` (controlled-controlled-NOT).
- **General**: `QControlledU[U, nQubits, control, target]` — Constructs controlled-$U$ gate for arbitrary $U$ and qubit layout.

**Circuit simulation (2 functions).**

- **`QCircuit[gates, nQubits]`** — Multiplies a sequence of gates (right to left) to produce the circuit unitary.
- **`QBellBasis`** — The four Bell states as a list.

**Quantum protocols (4 functions).** Fundamental information-processing primitives:

- **`QBellMeasurement[state]`** — Projects a two-qubit state onto the Bell basis; returns probabilities and outcomes.
- **`QTeleport[state, bellPair]`** — Full quantum teleportation protocol: Bell measurement on Alice's qubits, classical communication, Pauli correction on Bob's qubit.
- **`QSuperdenseCoding[bits, bellPair]`** — Encodes 2 classical bits into 1 qubit using a shared Bell pair.
- **`QNoCloneTest[stateA, stateB]`** — Verifies the no-cloning theorem: shows $\langle a | b \rangle = \langle a | b \rangle^2$ requires $|\langle a|b\rangle| \in \{0, 1\}$.

**Quantum error correction (7 functions).** Three codes of increasing power:

1. **3-qubit bit-flip code**: `QBitFlipEncode`, `QBitFlipCorrect` — Encodes $\alpha|0\rangle + \beta|1\rangle \to \alpha|000\rangle + \beta|111\rangle$. Corrects single $X$ errors.

2. **3-qubit phase-flip code**: `QPhaseFlipEncode`, `QPhaseFlipCorrect` — Hadamard-conjugate of bit-flip code. Encodes $|0\rangle_L = |{+}{+}{+}\rangle$, $|1\rangle_L = |{-}{-}{-}\rangle$. Corrects single $Z$ errors.

3. **Shor 9-qubit code**: `QShorEncode`, `QShorCorrect` — Concatenation of phase-flip and bit-flip codes. Corrects arbitrary single-qubit errors ($X$, $Y$, $Z$, or combinations). Verified against all 27 single-qubit error cases ($3$ error types $\times$ $9$ qubit positions).

- **`QKnillLaflamme[code, errors]`** — Tests the Knill-Laflamme quantum error correction conditions $P E_a^\dagger E_b P = c_{ab} P$ for a given code space projector $P$ and error set $\{E_a\}$. Correctly identifies that the bit-flip code satisfies KL for $\{I, X_1, X_2, X_3\}$ but fails for $\{I, Z_1\}$.

### Exploration: `qm_foundations_10_information.wls` (402 lines, 9 parts)

| Part | Topic | Key Results |
|------|-------|-------------|
| A | Quantum gates | $H^2 = I$, $S^2 = Z$, $T^2 = S$; all gates unitary |
| B | Circuit simulation | Bell pair, GHZ state preparation; SWAP $=$ 3 CNOTs |
| C | No-cloning theorem | $\langle a|b\rangle = \langle a|b\rangle^2$ violated for all non-orthogonal pairs |
| D | Teleportation | Unit fidelity for $|0\rangle$, $|1\rangle$, $|+\rangle$, arbitrary superpositions |
| E | Superdense coding | 4 messages (00, 01, 10, 11) decoded perfectly via Bell measurement |
| F | Bit-flip code | Single $X$ errors corrected; double errors fail (as expected) |
| G | Phase-flip code | Single $Z$ errors corrected; Hadamard-conjugate structure verified |
| H | Shor 9-qubit code | All 27 single-qubit errors ($X$, $Y$, $Z$ on each of 9 qubits) corrected |
| I | Knill-Laflamme | KL conditions satisfied for bit-flip code + $X$ errors; correctly fails for $Z$ errors |

### Tests: 30/30 pass

Ten test sections covering gate properties (unitarity, algebraic identities), gate actions on standard states, Bell state preparation, circuit simulation, no-cloning verification, teleportation fidelity, superdense coding, bit-flip/phase-flip correction, Shor code (27 error cases), and Knill-Laflamme conditions.

## Cumulative Project Status

After 11 cycles, the quantum foundations project is complete. All ten sub-topics have been explored with libraries, exploration scripts (9 of 10), and test suites.

### Libraries (10 total, 2,343 lines, 161 public functions)

| # | Library | Lines | Functions | Sub-Topic |
|---|---------|-------|-----------|-----------|
| 1 | `qm_postulates.wls` | 155 | 21 | Postulates & Hilbert Space |
| 2 | `qm_systems.wls` | 201 | 18 | Simple Quantum Systems |
| 3 | `qm_angular_momentum.wls` | 161 | 16 | Spin & Angular Momentum |
| 4 | `qm_measurement.wls` | 122 | 14 | The Measurement Problem |
| 5 | `qm_entanglement.wls` | 217 | 14 | Entanglement & Non-Locality |
| 6 | `qm_interpretations.wls` | 195 | 11 | Interpretations |
| 7 | `qm_path_integral.wls` | 248 | 14 | Path Integral Formulation |
| 8 | `qm_open_systems.wls` | 266 | 15 | Open Quantum Systems |
| 9 | `qm_hydrogen_helium.wls` | 279 | 16 | 3D Hydrogen & Helium |
| 10 | `qm_information.wls` | 499 | 22 | Quantum Information |

### Exploration Scripts (9 total, 5,339 lines)

| # | Script | Lines | Parts |
|---|--------|-------|-------|
| 1 | `qm_foundations_01_postulates.wls` | 814 | — |
| 2 | `qm_foundations_02_simple_systems.wls` | 976 | — |
| 3 | `qm_foundations_03_spin_angular_momentum.wls` | 798 | — |
| 4 | `qm_foundations_04_measurement.wls` | 545 | — |
| 5 | `qm_foundations_05_entanglement.wls` | 438 | — |
| 7 | `qm_foundations_07_path_integral.wls` | 490 | 7 |
| 8 | `qm_foundations_08_open_systems.wls` | 586 | 6 |
| 9 | `qm_foundations_09_hydrogen_helium.wls` | 290 | 9 |
| 10 | `qm_foundations_10_information.wls` | 402 | 9 |

Script 06 (Interpretations) was never produced — noted as a gap since Cycle 7.

### Test Results (all suites, verified 2026-03-20)

| # | Test Suite | Assertions | Status |
|---|-----------|------------|--------|
| 1 | `test_qm_postulates.wls` | 30 | 30/30 pass |
| 2 | `test_qm_systems.wls` | 26 | 26/26 pass |
| 3 | `test_qm_angular_momentum.wls` | 37 | 37/37 pass |
| 4 | `test_qm_measurement.wls` | 25 | 25/25 pass |
| 5 | `test_qm_entanglement.wls` | 28 | 28/28 pass |
| 6 | `test_qm_interpretations.wls` | 16 | 16/16 pass |
| 7 | `test_qm_path_integral.wls` | 22 | 22/22 pass |
| 8 | `test_qm_open_systems.wls` | 22 | 22/22 pass |
| 9 | `test_qm_hydrogen_helium.wls` | 31 | 31/31 pass |
| 10 | `test_qm_information.wls` | 30 | 30/30 pass |
| | **Total** | **267** | **267/267 pass** |

### Additional Artifacts

- 3 debug scripts (146 lines total): `debug_lattice.wls`, `debug_open.wls`, `debug_entropy.wls`
- `interact/` directory with 2 utility scripts (`hermite.wls`, `sinplot.wls`)
- 4 prior reports: `report_cycles_1-4.md/.pdf`, `report_cycles_5-6.md/.pdf/.tex`, `report_cycles_7-7.md/.pdf`

## Decisions

1. **Vectorized Lindblad dynamics.** The open systems library represents density matrices as vectors and the Lindblad equation as a superoperator matrix, enabling evolution via matrix exponentiation rather than ODE integration. This trades generality (limited to finite-dimensional systems where the full superoperator fits in memory) for exactness and simplicity.

2. **Lattice path integral via nested NIntegrate.** Rather than Monte Carlo sampling, the path integral is discretized as nested numerical integrals. This gives deterministic results but limits $N$ to roughly 10 slices. Sufficient for demonstrating convergence and the classical limit.

3. **Helium-specific variational tools.** The audit notes that `QVariationalEnergy` and `QVariationalMinimize` are specialized to helium rather than implementing general variational optimization over arbitrary trial wavefunctions. This is a reasonable simplification given that the general case requires symbolic integration or user-supplied energy functionals.

4. **Shor code as concatenation.** The 9-qubit Shor code is implemented as a concatenation of the 3-qubit phase-flip and bit-flip codes, following Shor's original construction. This makes the pedagogical structure clear — each code handles one error type, and their combination handles arbitrary errors.

5. **No new artifacts in Cycle 11.** Cycle 11 had only a researcher session (no worker or auditor). No new code was produced. This appears to be a wrap-up or planning cycle.

## Discrepancy: Audit Sub-Topic Numbering

The Cycle 9 audit report uses a different sub-topic numbering and naming scheme than the one established in prior reports:

| Audit # | Audit Name | This Report # | This Report Name |
|---------|-----------|---------------|-----------------|
| 1 | Postulates & Hilbert Space | 1 | Postulates |
| 2 | Hamiltonian Dynamics | 2 | Simple Quantum Systems |
| 6 | Lagrangian & Hamiltonian Mechanics | 6 | Interpretations |

The discrepancy in sub-topic 6 is notable: the audit calls it "Lagrangian & Hamiltonian Mechanics" while the actual library (`qm_interpretations.wls`) implements Bohmian mechanics, GRW collapse, consistent histories, and Many-Worlds branch analysis. The audit may have been using a research brief or syllabus that diverged from what was actually implemented.

The sub-topic 2 discrepancy ("Hamiltonian Dynamics" vs "Simple Quantum Systems") is less significant — the library `qm_systems.wls` covers harmonic oscillators, finite wells, and other systems with their Hamiltonians, so both names are defensible.

## Open Items

1. **Missing exploration script for Interpretations (Sub-Topic 6).** This gap has persisted since Cycle 7. The `qm_interpretations.wls` library has tools for Bohmian mechanics, GRW collapse, consistent histories, and Many-Worlds, but no exploration demonstrates their application to concrete scenarios.

2. **Git tracking.** All code in `quantum_foundations/` remains untracked in git. This has been noted in every report since cycles 1–4. The git status shows 31 untracked files.

3. **Cycle 8 audit gap.** The audit agent was unavailable for Cycle 8. Sub-Topics 7 (Path Integral) and 8 (Open Systems), produced in that cycle, were listed as validated in the Cycle 9 audit's cumulative table but were not independently audited with detailed sufficiency criteria.

4. **Cycle 10 audit not provided.** While Cycle 10 had an auditor session (2fa992a4), no audit report was included in the input for this report. Sub-Topic 10 (Quantum Information) has not been formally validated.

5. **Cycle 11 purpose unclear.** Cycle 11 had only a researcher session — no worker or auditor. No new artifacts were produced. The purpose and outcome of this cycle are unknown.

## Gaps in Record

1. **Session database inaccessible.** The 9 session IDs for cycles 8–11 (3 researcher, 3 worker, 3 auditor) could not be retrieved. This report is based entirely on disk artifacts and the provided audit report.

2. **Cycle-to-sub-topic mapping is inferred.** The assignment of sub-topics 7–8 to Cycle 8 and sub-topic 9 to Cycle 9 is reconstructed from file modification timestamps, not from session data.

3. **No audit reports for Sub-Topics 7, 8, and 10.** Only Sub-Topic 9 has a detailed audit with sufficiency criteria. The audit cumulative table lists sub-topics 7 and 8 as "VALIDATED" but the audit reports that validated them were not provided. Sub-Topic 10 has no audit status.
