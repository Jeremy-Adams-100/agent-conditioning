---
title: "Quantum Mechanics Foundations — Cycles 5–6"
subtitle: "The Measurement Problem, Entanglement, and Non-Locality"
date: "March 2026"
geometry: margin=1in
---

# Overview

Cycles 5 and 6 completed two major sub-topics of the quantum mechanics foundations exploration.
Cycle 5 addressed the **measurement problem** — why quantum measurements yield definite outcomes — through von Neumann's measurement scheme, quantum channels (Kraus operators), decoherence via system-environment entanglement, pointer states, and the quantum-to-classical transition.
Cycle 6 addressed **entanglement and non-locality** — whether quantum correlations can be explained by local hidden variables — through the EPR argument, Bell's theorem and the CHSH inequality, entanglement measures (entropy, concurrence, negativity), multipartite entanglement classification (GHZ vs.\ W states), and the no-cloning theorem.

Together, these cycles added 2 new libraries (339 lines, 28 public functions), 2 exploration scripts (983 lines), and 2 test suites (53 assertions, all passing).

# Cycle 5: The Measurement Problem

## Library: `lib/qm_measurement.wls`

This cycle produced a 122-line library packaged as `QMMeasurement` with 14 public functions organized into four groups.

**Mixed state construction** (4 functions):

- `QMixedState[{{p1, rho1}, ...}]` — constructs a density matrix $\rho = \sum_i p_i \rho_i$ from an ensemble of states weighted by probabilities.
- `QMaximallyMixed[d]` — returns the $d \times d$ identity matrix divided by $d$, the maximally mixed state.
- `QVonNeumannEntropy[rho]` — computes $S(\rho) = -\mathrm{Tr}(\rho \log_2 \rho)$ via eigenvalue decomposition, filtering eigenvalues below $10^{-12}$ to avoid numerical $\log(0)$.
- `QPurity[rho]` — computes $\mathrm{Tr}(\rho^2)$, which equals 1 for pure states and $1/d$ for the maximally mixed state of dimension $d$.

**Quantum channels** (6 functions):

- `QKrausApply[krausOps, rho]` — applies a quantum channel in Kraus form: $\rho \mapsto \sum_k M_k \rho M_k^\dagger$.
- `QIsTPChannel[krausOps]` — verifies the trace-preserving condition $\sum_k M_k^\dagger M_k = I$.
- `QDephasingChannel[p]` — returns Kraus operators $\{\sqrt{1-p}\,I, \sqrt{p}\,\sigma_z\}$. At $p = 1/2$ this completely eliminates off-diagonal elements.
- `QDepolarizingChannel[p]` — returns four Kraus operators $\{\sqrt{1 - 3p/4}\,I, \sqrt{p/4}\,\sigma_x, \sqrt{p/4}\,\sigma_y, \sqrt{p/4}\,\sigma_z\}$. At $p = 1$ this maps any state to $I/2$.
- `QAmplitudeDampingChannel[gamma]` — models spontaneous emission with two Kraus operators. At $\gamma = 1$ the excited state decays completely to the ground state.
- `QProjectiveChannel[basisVectors]` — constructs Kraus operators $M_k = |b_k\rangle\langle b_k|$ for projective measurement. Applying this channel is equivalent to non-selective measurement (all off-diagonals destroyed, populations preserved).

**Decoherence models** (2 functions):

- `QSystemEnvironmentEvolve[Htotal, psiTotal0, t, dimSys]` — evolves a joint system-environment state under a total Hamiltonian $H$ for time $t$ using $U = e^{-iHt}$, then returns the reduced system density matrix by tracing out the environment. The partial trace is computed via explicit index summation over environment degrees of freedom.
- `QDecoherenceTrack[Htotal, psiTotal0, tList, dimSys]` — calls `QSystemEnvironmentEvolve` at each time in `tList` and returns a list of $\{t, \rho_S(t)\}$ pairs.

**Bloch vector** (1 function):

- `QBlochVector[rho]` — extracts the Bloch vector $(r_x, r_y, r_z)$ from a $2 \times 2$ density matrix via $r_x = 2\,\mathrm{Re}(\rho_{01})$, $r_y = 2\,\mathrm{Im}(\rho_{10})$, $r_z = \rho_{00} - \rho_{11}$.

**Coherence measure** (1 function):

- `QCoherence[rho]` — returns $|\rho_{01}|$, the magnitude of the off-diagonal element of a $2 \times 2$ density matrix, used as a scalar measure of quantum coherence.

## Exploration: `qm_foundations_04_measurement.wls`

This 545-line exploration script is organized into five parts (A--E). It depends on the `QMPostulates` library from Cycle 1 and the new `QMMeasurement` library.

### Part A: Von Neumann's Measurement Scheme

The exploration begins with the textbook measurement model. A qubit system $S$ and a qubit apparatus $A$ interact via a CNOT gate (system = control, apparatus = target). The CNOT maps $|0\rangle_S |0\rangle_A \to |0\rangle_S |0\rangle_A$ and $|1\rangle_S |0\rangle_A \to |1\rangle_S |1\rangle_A$, so the apparatus "reads" the system in the computational basis.

Applying this to a superposition $|{+}\rangle_S = (|0\rangle + |1\rangle)/\sqrt{2}$ produces:
$$\text{CNOT}|{+}\rangle_S |0\rangle_A = \frac{|00\rangle + |11\rangle}{\sqrt{2}}$$
This is a Bell state — maximally entangled — not a collapsed state. The unitary evolution creates entanglement, not collapse.

The reduced density matrix $\rho_S = \mathrm{Tr}_A(|\psi\rangle\langle\psi|)$ is computed as $\frac{1}{2}|0\rangle\langle 0| + \frac{1}{2}|1\rangle\langle 1|$, a mixed state with the correct Born rule probabilities ($P(0) = P(1) = 1/2$). The global state remains pure ($\mathrm{Tr}(\rho_{SA}^2) = 1$) while the local state is mixed ($\mathrm{Tr}(\rho_S^2) = 0.5$). Purity has migrated into system-apparatus correlations.

The script then sweeps the superposition parameter $\alpha$ in $|\psi\rangle = \alpha|0\rangle + \sqrt{1 - \alpha^2}|1\rangle$ and plots the von Neumann entropy $S(\rho_S)$ versus $\alpha$, confirming that entropy is maximized at $\alpha = 1/\sqrt{2}$ (maximal entanglement with the apparatus).

### Part B: Quantum Channels and Generalized Measurement

Projective measurement is recast as a quantum channel (Kraus operators $M_k = |k\rangle\langle k|$). Applied to $|{+}\rangle\langle{+}|$, the off-diagonals are destroyed, yielding the same diagonal mixture as Part A. The channel is verified to be idempotent (measuring twice equals measuring once).

Three standard quantum channels are then explored quantitatively:

- **Dephasing** ($p = 0$ to $1$, step $0.25$): off-diagonals decay as $(1 - 2p)\rho_{01}$; at $p = 0.5$ complete dephasing; at $p = 1$ the coherence inverts (sign flip).
- **Depolarizing** ($p = 0$ to $1$, step $0.25$): the Bloch vector shrinks uniformly toward the origin; at $p = 1$ the state becomes $I/2$.
- **Amplitude damping** ($\gamma = 0$ to $1$, step $0.25$): population transfers from $|1\rangle$ to $|0\rangle$; at $\gamma = 1$ full decay to the ground state $|0\rangle\langle 0|$.

All three channels are verified to be trace-preserving. Iterated dephasing ($p = 0.1$ applied $n$ times) is shown to produce exponential coherence decay: $|\rho_{01}| = \frac{1}{2}(1 - 2p)^n = \frac{1}{2}(0.8)^n$, confirmed numerically to $10^{-8}$ precision for $n = 1, 2, 5, 10, 20$. This establishes the discrete model of decoherence.

### Part C: Decoherence via System-Environment Entanglement

The exploration constructs explicit system-environment Hamiltonians of the form $H = \sum_k g_k \sigma_z^{(0)} \otimes \sigma_z^{(k)}$, where qubit 0 is the system and qubits 1 through $N$ are environment qubits. Environment qubits start in $|{+}\rangle$ (not eigenstates of $\sigma_z$) so that decoherence occurs.

**$N = 1$ environment qubit** (dim = 4): coherence oscillates as $|\rho_{01}(t)| = \frac{1}{2}|\cos(2gt)|$, with full revivals. There is no irreversible decoherence — the environment is too small to act as a reservoir. The numerical results match the analytical formula to machine precision.

**$N = 1$ to $4$ with equal couplings** ($g_k = 1.0$): coherence follows the product formula $|\rho_{01}(t)| = \frac{1}{2}\prod_k |\cos(2g_k t)|$. With identical couplings, revivals still occur (all cosines have the same period), but the envelope decays faster with increasing $N$.

**$N = 1$ to $4$ with random couplings** ($g_k \in [0.5, 1.5]$, seeded): random couplings break commensurability between oscillation frequencies, suppressing revivals. For $N = 4$ the coherence remains near zero after $t \approx 2$, demonstrating effectively irreversible decoherence even in a finite (32-dimensional) Hilbert space.

### Part D: Pointer States and Einselection

The concept of *pointer states* — the states that are robust against decoherence — is demonstrated through two complementary experiments with $N_{\text{env}} = 3$ environment qubits.

**$\sigma_z \otimes \sigma_z$ coupling**: the system state $|\psi(\theta)\rangle = \cos(\theta/2)|0\rangle + \sin(\theta/2)|1\rangle$ is swept from $\theta = 0$ to $\pi$. States near the poles ($|0\rangle$ and $|1\rangle$) maintain purity $\approx 1$; the equatorial state $|{+}\rangle$ ($\theta = \pi/2$) decoheres maximally. The pointer states are the eigenstates of $\sigma_z$ — the system operator appearing in $H_{\text{int}}$.

**$\sigma_x \otimes \sigma_x$ coupling** (same couplings, environment in $|0\rangle$): the pointer basis rotates by 90°. Now $|{+}\rangle$ ($\theta = \pi/2$) maintains purity, while $|0\rangle$ and $|1\rangle$ decohere maximally. The pointer states are the eigenstates of $\sigma_x$.

The *einselection criterion* is stated explicitly: pointer states are the eigenstates of the system operator in $H_{\text{int}}$, because $[A, A] = 0$ guarantees that eigenstates of $A$ are invariant under $A$-type coupling. This is verified computationally: $[\sigma_z, \sigma_z] = 0$ while $[\sigma_x, \sigma_z] \neq 0$.

### Part E: Quantum-to-Classical Transition

**GHZ decoherence scaling**: the $n$-qubit GHZ state $(|0\rangle^{\otimes n} + |1\rangle^{\otimes n})/\sqrt{2}$ is coupled to $n$ environment qubits (each via $\sigma_z \otimes \sigma_z$, $g = 1.0$). The GHZ coherence decays as $|\cos(2gt)|^n$, verified numerically for $n = 1, 2, 3$.

The decoherence time $t_d$ (defined by $|\rho_{01}| = 1/(2e)$) is computed analytically as $t_d = \arccos(e^{-1/n})/(2g)$. For macroscopic $n$, this scales as $t_d \sim 1/(2g\sqrt{n})$. At typical physical scales ($g \sim 10^{10}$ Hz, $n \sim 10^{23}$), $t_d \sim 10^{-22}$ seconds — macroscopic superpositions decohere before they can be observed.

**The "and/or" problem**: the exploration concludes by demonstrating what decoherence does *not* solve. At late times, the global state remains pure ($\mathrm{Tr}(\rho_{SE}^2) = 1$) while the reduced system state is approximately diagonal. Decoherence converts superposition ("and") into something that *looks like* a classical mixture ("or"), but the global state is still a superposition. Selecting a *specific* outcome requires an additional interpretive step (Copenhagen collapse, many-worlds branching, Bohmian hidden variables, or QBist probability updating). This is flagged as the subject of a future sub-topic on quantum interpretations.

## Test Suite: `test_qm_measurement.wls`

25 assertions, all passing. Coverage spans:

| Category | Tests | What is verified |
|---|---|---|
| Mixed states | 4 | Valid density matrix from ensemble; eigenvalues of $I/d$; entropy of pure state = 0; entropy of $I/2$ = 1 bit |
| Purity | 3 | Pure state purity = 1; $I/4$ purity = 0.25; purity decreases under dephasing |
| Quantum channels | 7 | TP condition for dephasing, depolarizing, amplitude damping; trace preservation; dephasing at $p=0.5$ kills off-diagonals; depolarizing at $p=1$ gives $I/2$; amplitude damping at $\gamma=1$ maps $|1\rangle$ to $|0\rangle$ |
| Projective channel | 2 | Destroys off-diagonals; idempotent |
| Decoherence | 4 | Valid density matrix from evolution; pointer state $|0\rangle$ stays pure; non-pointer $|{+}\rangle$ loses purity; coherence matches $\cos(2gt)$ analytically |
| Bloch vector | 3 | $|0\rangle \to (0,0,1)$; $I/2 \to (0,0,0)$; $|\mathbf{r}| \leq 1$ |
| Pointer basis | 2 | $|0\rangle$ stable under $\sigma_z$ coupling; $|{+}\rangle$ stable under $\sigma_x$ coupling |

# Cycle 6: Entanglement and Non-Locality

## Library: `lib/qm_entanglement.wls`

This cycle produced a 217-line library packaged as `QMEntanglement` with 14 public functions organized into five groups. The library is self-contained (no cross-package dependencies), using internal helper functions for partial trace, von Neumann entropy, density matrix construction, and spin observables.

**Entanglement measures** (4 functions):

- `QEntanglementEntropy[state, {dimA, dimB}]` — computes the von Neumann entropy of the reduced state $\rho_A$ obtained by tracing out subsystem $B$. For a bipartite pure state, this equals the entanglement entropy.
- `QConcurrence[rho]` — implements the Wootters concurrence for a $4 \times 4$ two-qubit density matrix: $C(\rho) = \max(0, \sqrt{\lambda_1} - \sqrt{\lambda_2} - \sqrt{\lambda_3} - \sqrt{\lambda_4})$, where $\lambda_i$ are the eigenvalues of $\rho \tilde{\rho}$ in decreasing order, with $\tilde{\rho} = (\sigma_y \otimes \sigma_y)\rho^*(\sigma_y \otimes \sigma_y)$.
- `QNegativity[rho, {dimA, dimB}]` — computes the negativity $\mathcal{N}(\rho) = (\|\rho^{T_B}\|_1 - 1)/2$, where $\rho^{T_B}$ is the partial transpose over subsystem $B$.
- `QLogNegativity[rho, {dimA, dimB}]` — computes $E_{\mathcal{N}} = \log_2(2\mathcal{N} + 1)$.

**Partial transpose** (1 function):

- `QPartialTranspose[rho, {dimA, dimB}, sub]` — computes the partial transpose over subsystem `sub` (1 or 2) by swapping the appropriate indices in the bipartite matrix structure.

**Bell/CHSH tools** (4 functions):

- `QCorrelation[stateOrRho, obsA, obsB]` — computes $E(A, B) = \langle A \otimes B \rangle$ for either a pure state vector or a density matrix.
- `QCHSHOperator[a, ap, b, bp]` — constructs the CHSH operator $\mathcal{B} = A \otimes B - A \otimes B' + A' \otimes B + A' \otimes B'$ from four unit vectors defining spin measurement axes.
- `QCHSHValue[stateOrRho, a, ap, b, bp]` — evaluates the CHSH parameter $S = \langle \mathcal{B} \rangle$.
- `QOptimalCHSH[stateOrRho]` — computes the maximum achievable $|S|$ via the Horodecki criterion: $S_{\max} = 2\sqrt{m_1 + m_2}$, where $m_1, m_2$ are the two largest eigenvalues of $T^T T$ and $T_{ij} = \mathrm{Tr}(\rho\,\sigma_i \otimes \sigma_j)$ is the correlation matrix.

**Schmidt decomposition** (3 functions):

- `QSchmidtDecomposition[state, {dimA, dimB}]` — reshapes the state vector into a $d_A \times d_B$ coefficient matrix, computes its SVD, and returns Schmidt coefficients with corresponding basis vectors for each subsystem.
- `QSchmidtRank[state, {dimA, dimB}]` — returns the number of non-zero Schmidt coefficients (those above $10^{-10}$).
- `QIsEntangled[stateOrRho, {dimA, dimB}]` — for pure states, checks Schmidt rank $> 1$; for density matrices, checks whether the partial transpose has a negative eigenvalue (PPT criterion).

**Multipartite** (2 functions):

- `QWState[n]` — constructs the $n$-qubit W state $(|00\dots01\rangle + |00\dots10\rangle + \cdots + |10\dots00\rangle)/\sqrt{n}$ as a column vector.
- `Q3Tangle[state]` — computes the 3-tangle (residual tripartite entanglement) for a 3-qubit pure state using the Coffman-Kundu-Wootters (CKW) decomposition: $\tau_3 = C^2(A{:}BC) - C^2(A{:}B) - C^2(A{:}C)$. Internal helper `traceOutMiddle` handles the non-standard partial trace over the middle qubit.

## Exploration: `qm_foundations_05_entanglement.wls`

This 438-line exploration script is organized into six parts (A--F). It depends on the `QMPostulates`, `QMMeasurement`, and `QMEntanglement` libraries.

### Part A: The EPR Argument and Perfect Correlations

The singlet state $|\Psi^-\rangle = (|01\rangle - |10\rangle)/\sqrt{2}$ is constructed and its correlations are measured along five axes: $\hat{z}$, $\hat{x}$, $\hat{y}$, $(\hat{x}+\hat{z})/\sqrt{2}$, and $(\hat{x}+\hat{y}+\hat{z})/\sqrt{3}$. In every case, $E(\hat{n}, \hat{n}) = -1$ — perfect anti-correlation along any axis. This reproduces the EPR argument: measuring one particle's spin along any axis predicts the other's with certainty, suggesting that all spin components are simultaneously "elements of reality."

The no-signaling property is verified: the reduced density matrix $\rho_2 = \mathrm{Tr}_1(|\Psi^-\rangle\langle\Psi^-|) = I/2$ regardless of what measurement is performed on particle 1. Even after selective projection of particle 1 onto $|0\rangle$ or $|1\rangle$, the non-selective (averaged) reduced state of particle 2 remains $I/2$. No information is transmitted.

### Part B: Bell's Theorem and the CHSH Inequality

The CHSH inequality is stated: local hidden variable (LHV) theories predict $|S| \leq 2$, while quantum mechanics permits up to $|S| = 2\sqrt{2} \approx 2.82843$ (the Tsirelson bound).

Three measurement configurations are tested on the singlet:

1. $a = 0°$, $a' = 90°$, $b = 45°$, $b' = 135°$: $|S| = 2\sqrt{2}$ — **maximal violation**.
2. $a = 0°$, $a' = 90°$, $b = -45°$, $b' = 45°$: $|S| = 2\sqrt{2}$ — also maximal.
3. $a = b = 0°$, $a' = b' = 90°$ (aligned): $|S| = 2$ — no violation.

An angle sweep (0° to 180° in 15° steps) maps out the full dependence of $S$ on the measurement angle, confirming the maximum at 45° and the crossings at 0° and 90°.

`QOptimalCHSH` is verified against the Tsirelson bound: it returns $2\sqrt{2}$ for the singlet, matching the theoretical value to 10 digits.

The connection between entanglement and Bell violation is established quantitatively. For the family $|\psi(\alpha)\rangle = \cos\alpha|00\rangle + \sin\alpha|11\rangle$, the optimal CHSH value is $S_{\max} = 2\sqrt{1 + C^2}$, where $C$ is the concurrence. At $C = 0$ (product state), $S_{\max} = 2$ exactly (no violation possible); at $C = 1$ (Bell state), $S_{\max} = 2\sqrt{2}$.

### Part C: Entanglement Measures

**Schmidt decomposition**: verified for four states. Product state $|00\rangle$ has Schmidt rank 1; Bell states $|\Phi^+\rangle$ and $|\Psi^-\rangle$ have rank 2 with equal coefficients $1/\sqrt{2}$; a partially entangled state $|\psi(\pi/6)\rangle$ has rank 2 with unequal coefficients.

**Entanglement entropy sweep**: for $|\psi(\alpha)\rangle = \cos\alpha|00\rangle + \sin\alpha|11\rangle$ with $\alpha = 0°$ to $45°$ in $5°$ steps, all four measures are computed in parallel:

- Entanglement entropy $S(\rho_A)$: 0 at $\alpha = 0°$, 1 bit at $\alpha = 45°$.
- Concurrence $C$: 0 to 1.
- Negativity $\mathcal{N}$: 0 to 0.5.
- Purity $\mathrm{Tr}(\rho_A^2)$: 1 to 0.5.

All measures are monotonically consistent: more entanglement = larger $S$, $C$, $\mathcal{N}$, and smaller purity.

**Werner states**: the family $\rho_W = p|\Psi^-\rangle\langle\Psi^-| + (1-p)I/4$ is examined for $p = 0$ to $1$. Two thresholds emerge:

- **Entanglement threshold** ($p > 1/3$): concurrence becomes positive, matching the analytical formula $C = \max(0, (3p-1)/2)$.
- **Bell violation threshold** ($p > 1/\sqrt{2} \approx 0.707$): $S_{\max} > 2$, with $S_{\max} = 2\sqrt{2}\,p$.

The gap $1/3 < p < 1/\sqrt{2}$ contains states that are entangled but do *not* violate the CHSH inequality. Entanglement is necessary but not sufficient for Bell violation.

### Part D: Partial Transpose and the PPT Criterion

The Peres-Horodecki criterion is demonstrated: for $2 \times 2$ (and $2 \times 3$) systems, a state is entangled if and only if its partial transpose has a negative eigenvalue (NPT).

Five states are tested: a product state (all positive eigenvalues, PPT, separable), two Bell states (minimum eigenvalue $-1/2$, NPT, entangled), Werner $p = 0.5$ (entangled, NPT, closer to PPT boundary), and Werner $p = 0.2$ (PPT, separable). Results are fully consistent with the concurrence analysis.

### Part E: Multipartite Entanglement — GHZ vs.\ W

The 3-qubit GHZ state $|\text{GHZ}\rangle = (|000\rangle + |111\rangle)/\sqrt{2}$ and W state $|W\rangle = (|001\rangle + |010\rangle + |100\rangle)/\sqrt{3}$ are compared across three measures.

**Reduced states after partial trace**:

- GHZ: tracing out one qubit gives $\rho_{AB} = \frac{1}{2}|00\rangle\langle 00| + \frac{1}{2}|11\rangle\langle 11|$ with concurrence $C = 0$. The reduced state is **separable**. GHZ entanglement is fragile — losing one qubit destroys all entanglement.
- W: tracing out one qubit gives a state with concurrence $C = 2/3$. The reduced state is **entangled**. W entanglement is robust — it is distributed across all pairs.

**3-tangle** ($\tau_3$):

- GHZ: $\tau_3 = 1$. All entanglement is genuinely tripartite (no pairwise entanglement, $C(A{:}B) = 0$).
- W: $\tau_3 = 0$. All entanglement is pairwise (the CKW inequality $C^2(A{:}BC) \geq C^2(A{:}B) + C^2(A{:}C)$ is saturated: $8/9 = 4/9 + 4/9$).

These are the two inequivalent SLOCC (stochastic local operations and classical communication) classes of genuine 3-qubit entanglement.

**Entanglement monogamy** (CKW inequality): verified for both states. This is the fundamental constraint that maximal entanglement with one partner limits entanglement with others — a property central to quantum cryptography.

### Part F: No-Cloning and No-Signaling

The **no-cloning theorem** is demonstrated constructively. A CNOT gate (the simplest "copy" operation) clones the computational basis: $|0\rangle|0\rangle \to |0\rangle|0\rangle$ and $|1\rangle|0\rangle \to |1\rangle|1\rangle$. But applied to $|{+}\rangle|0\rangle$, linearity forces the output to $(|00\rangle + |11\rangle)/\sqrt{2}$ — a Bell state, not $|{+}\rangle|{+}\rangle$. The cloning fidelity is $|\langle{+},{+}|U|{+},0\rangle|^2 = 1/2$, not 1.

The **connection to no-signaling** is made explicit: if cloning were possible, one could clone a shared Bell pair to determine the local state, which depends on the distant partner's measurement choice. This would enable superluminal signaling. No-cloning prevents this; the reduced state of one partner is always $I/2$ regardless of actions on the other.

## Test Suite: `test_qm_entanglement.wls`

28 assertions, all passing. Coverage spans:

| Category | Tests | What is verified |
|---|---|---|
| Schmidt decomposition | 4 | Product rank = 1; Bell rank = 2 with equal coefficients; reconstruction fidelity; coefficients non-negative and sorted |
| Entanglement entropy | 3 | $S = 0$ for product; $S = 1$ for Bell; $S$ matches $-c^2 \log_2 c^2 - s^2 \log_2 s^2$ |
| Concurrence | 5 | $C = 0$ for product; $C = 1$ for all 4 Bell states; $C = |\sin 2\alpha|$ for partial entanglement; Werner formula $\max(0, (3p-1)/2)$; non-negativity |
| Partial transpose | 3 | Product PPT; Bell NPT ($-1/2$); trace preserved |
| Negativity | 3 | $\mathcal{N} = 0$ for product; $\mathcal{N} = 1/2$ for Bell; $\mathcal{N} > 0 \iff C > 0$ |
| CHSH | 4 | $|S| = 2\sqrt{2}$ for singlet; $|S| \leq 2$ for product; Werner $S_{\max} = 2\sqrt{2}p$; $S_{\max} = 2\sqrt{1+C^2}$ for pure states |
| Multipartite | 4 | GHZ reduced separable ($C=0$); W reduced entangled ($C=2/3$); GHZ 3-tangle = 1; W 3-tangle = 0 |
| No-cloning | 2 | CNOT fails to clone $|{+}\rangle$; fidelity = $1/2$ |

# Validation Summary

With cycles 5 and 6 complete, the cumulative project statistics are:

| Metric | Cycles 1–4 | Cycle 5 | Cycle 6 | Total |
|---|---|---|---|---|
| Libraries | 3 (517 lines) | 1 (122 lines) | 1 (217 lines) | 5 (856 lines) |
| Public functions | 54 | 14 | 14 | 82 |
| Exploration scripts | 3 (2,588 lines) | 1 (545 lines) | 1 (438 lines) | 5 (3,571 lines) |
| Test assertions | 99 | 25 | 28 | 152 |
| Pass rate | 99/99 | 25/25 | 28/28 | 152/152 |
| Critical issues | 0 | 0 | 0 | 0 |

All 152 test assertions pass. No regressions were introduced by cycles 5–6.

# Cross-Cutting Connections

Cycles 5 and 6 form a natural pair that addresses the two deepest conceptual puzzles of quantum mechanics: what happens during measurement, and what kind of correlations exist between separated systems.

**Decoherence connects to entanglement**: the central mechanism of decoherence (Cycle 5) *is* entanglement with the environment. The partial trace that produces mixed reduced states is the same operation used in Cycle 6 to define entanglement entropy. The GHZ decoherence scaling (Cycle 5, Part E) reappears conceptually in Cycle 6's analysis of GHZ fragility — both demonstrate that GHZ-type states are exponentially sensitive to perturbation.

**Library layering**: Cycle 6's exploration script loads all three prior libraries (`QMPostulates`, `QMMeasurement`, `QMEntanglement`), using `QDensityMatrix` and `QPartialTrace` from Cycle 1 alongside the new entanglement functions. The `QMEntanglement` library is intentionally self-contained (its own internal `ptrace` and `vnEntropy`), avoiding cross-package dependencies that would complicate testing.

**Measurement $\to$ entanglement $\to$ interpretation arc**: Cycle 5 ends by identifying what decoherence cannot explain (the "and/or" problem). Cycle 6 provides the mathematical tools (Bell inequalities, entanglement measures) needed to make this distinction precise. The gap between entangled-but-not-Bell-violating Werner states ($1/3 < p < 1/\sqrt{2}$) demonstrates that entanglement is a richer structure than Bell non-locality, a distinction that will be relevant for a future interpretations sub-topic.

**Connection to earlier cycles**: the Pauli algebra from Cycle 1, the coherent-state formalism from Cycle 2, and the Clebsch-Gordan coupling from Cycle 3 all provide infrastructure that the new cycles build on implicitly (e.g., Pauli matrices for constructing channels and CHSH operators, tensor products for bipartite states).

# Open Items

1. **Cycle 4 completion**: the restored context from the previous report notes that Cycle 4 had only a researcher session completed (ID: `0358706d`). The current cycles 5–6 appear to have completed the measurement and entanglement sub-topics that Cycle 4 was meant to begin.

2. **Interpretations sub-topic**: Cycle 5's exploration explicitly flags a future "Sub-Topic 6: Interpretations" to address the and/or problem. This has not yet been started.

3. **Git tracking**: all code in `quantum_foundations/` remains untracked in git (noted in the cycles 1–4 report and still unresolved).

4. **Cross-library dependency**: `QMEntanglement` duplicates partial trace and von Neumann entropy internally rather than importing from `QMPostulates` or `QMMeasurement`. This is a deliberate design choice (self-containment for independent testing) but introduces code duplication.

5. **Higher-dimensional entanglement**: all current entanglement tools are specialized for 2-qubit or 3-qubit systems. Extension to qudits or larger multipartite systems would require generalized partial transpose and multipartite entanglement witnesses.

6. **Bound entanglement**: the PPT criterion is necessary and sufficient only for $2 \times 2$ and $2 \times 3$ systems. Bound entangled states (PPT but entangled) exist in higher dimensions and are not currently detectable.

# Gaps in Record

1. **Session database inaccessible**: the session database at `agent-conditioning/agent/data/sessions.db` is in an off-limits directory. Individual session summaries for the researcher, worker, and auditor sessions of cycles 5–6 could not be retrieved. This report is based entirely on the artifacts on disk (library code, exploration scripts, test files, and test output).

2. **No audit report provided**: the `[INPUT: audit_report]` field was empty. Any audit findings from cycles 5–6 are not reflected in this report.

3. **Cycle 4 ambiguity**: the previous report listed Cycle 4 as "in progress" with only a researcher session. The current cycles 5–6 cover sub-topics 4 (Measurement) and 5 (Entanglement), suggesting Cycle 4 may have been completed as part of Cycle 5, or the sub-topic numbering was adjusted. The exact resolution is not documented in any accessible record.
