# Quantum Mechanics Foundations — Cycles 1–4

## Overview

Cycles 1–4 explored the mathematical and computational foundations of
non-relativistic quantum mechanics using Wolfram Language. Three sub-topics
were fully developed and validated: (1) the postulates and mathematical
formalism, (2) canonical exactly-solvable systems, and (3) spin and angular
momentum via SU(2) representation theory. A fourth sub-topic (the
measurement problem) was initiated with a research brief but has not yet
entered the implementation phase. The work produced three reusable Wolfram
libraries (54 public functions, 517 lines), three pedagogical exploration
scripts (2,588 lines), and three test suites (99 test assertions, all
passing).

---

## 1. Infrastructure and Design Conventions

All code resides in `quantum_foundations/` within the `wolfram-bridge`
project. The directory is organized into a `lib/` subdirectory for
reusable libraries and top-level scripts for exploration and testing:

```
quantum_foundations/
├── lib/
│   ├── qm_postulates.wls      (155 lines, 20 public functions)
│   ├── qm_systems.wls          (201 lines, 18 public functions)
│   └── qm_angular_momentum.wls (161 lines, 16 public functions)
├── qm_foundations_01_postulates.wls           (814 lines, Parts A–G)
├── qm_foundations_02_simple_systems.wls        (976 lines, Parts A–E)
├── qm_foundations_03_spin_angular_momentum.wls (798 lines, Parts A–E)
├── test_qm_postulates.wls       (32 test assertions)
├── test_qm_systems.wls          (28 test assertions)
└── test_qm_angular_momentum.wls (39 test assertions)
```

**Design conventions adopted across all three cycles:**

- **Units:** $\hbar = 1$ throughout. Hydrogen calculations use atomic
  units ($m_e = e = 4\pi\varepsilon_0 = 1$).
- **State representation:** Quantum states are column vectors (kets),
  operators are matrices. This is the finite-dimensional matrix mechanics
  formulation.
- **Packages:** Each library is a self-contained Wolfram package
  (`BeginPackage`/`EndPackage`) with explicit usage messages for every
  public function.
- **Sparse arrays:** Ladder operators and tridiagonal Hamiltonians use
  `SparseArray` for efficiency, converted to dense form via `Normal[]`
  for downstream operations.
- **Naming:** All public functions begin with `Q` (for "quantum"):
  `QState`, `QJz`, `QHydrogenRadial`, etc.

Each exploration script is a standalone executable (`wolframscript`) that
loads the relevant libraries, performs computations, and prints a
structured narrative with results. The scripts are pedagogical: they
state the physics, perform the calculation, and explain the result.

---

## 2. Cycle 1: The Postulates of Quantum Mechanics

### Research and Implementation

Cycle 1 addressed Sub-Topic 1 — the axiomatic foundations of quantum
mechanics. A research brief defined the scope: implement and verify all
five postulates using the qubit ($\mathbb{C}^2$) as the primary example
system, then demonstrate the uncertainty principle and canonical
quantization.

The worker produced:

- **Library `qm_postulates.wls`** (155 lines, 20 functions) covering
  state representation, observables, measurement, dynamics, and composite
  systems.
- **Exploration script `qm_foundations_01_postulates.wls`** (814 lines,
  7 parts).
- **Test suite `test_qm_postulates.wls`** (32 assertions across 10
  categories).

### Physics Content

The exploration script proceeds through seven parts:

**Part A — The State Space.** Constructs the qubit Hilbert space
$\mathbb{C}^2$ with computational basis $\{|0\rangle, |1\rangle\}$.
Demonstrates superposition, inner products, and the completeness
relation $\sum_n |n\rangle\langle n| = I$. Verifies orthonormality of
basis states.

**Part B — Observables as Hermitian Operators.** Introduces the Pauli
matrices $\sigma_x$, $\sigma_y$, $\sigma_z$ as observables. Verifies
Hermiticity, computes eigenvalues ($\pm 1$), and performs spectral
decomposition $A = \sum_n a_n |a_n\rangle\langle a_n|$. Demonstrates
that $[\sigma_x, \sigma_y] = 2i\sigma_z$ and verifies the
Pauli product identity $\sigma_x \sigma_y \sigma_z = iI$.

**Part C — The Born Rule.** Computes measurement probabilities via
$P(a_n) = |\langle a_n|\psi\rangle|^2$. Key result: measuring $|+\rangle
= (|0\rangle + |1\rangle)/\sqrt{2}$ in the $\sigma_z$ eigenbasis yields
50/50 probabilities — a definite state producing a random outcome in an
incompatible basis. Expectation values $\langle A \rangle =
\langle\psi|A|\psi\rangle$ and variance $(\Delta A)^2 = \langle A^2
\rangle - \langle A \rangle^2$ are computed for several states, showing
that eigenstates have zero variance while superposition states have
nonzero variance.

**Part D — Unitary Time Evolution.** Implements the propagator $U(t) =
e^{-iHt}$ and demonstrates Rabi oscillations in a spin-$\frac{1}{2}$
system driven by a magnetic field. Verifies that $U(t)$ is unitary
($U^\dagger U = I$), that norms are preserved under evolution, and
that $U(0) = I$.

**Part E — Composite Systems.** Constructs the two-qubit Hilbert space
$\mathbb{C}^2 \otimes \mathbb{C}^2$ via Kronecker products. Builds all
four Bell states:
$$|\Phi^\pm\rangle = \frac{|00\rangle \pm |11\rangle}{\sqrt{2}}, \quad
|\Psi^\pm\rangle = \frac{|01\rangle \pm |10\rangle}{\sqrt{2}}$$
Demonstrates the partial trace: for the product state $|+\rangle \otimes
|0\rangle$, the reduced density matrix is pure ($\text{Tr}(\rho_A^2) = 1$);
for the Bell state $|\Phi^+\rangle$, the reduced density matrix is
$I/2$ — maximally mixed ($\text{Tr}(\rho_A^2) = 1/2$). This is the
computational signature of entanglement: subsystem information is
encoded entirely in correlations.

**Part F — The Uncertainty Principle.** Derives and numerically verifies
the Robertson inequality:
$$\Delta A \cdot \Delta B \geq
\frac{1}{2}|\langle [A, B] \rangle|$$
Verified for multiple state-observable pairs, including the
Cauchy–Schwarz derivation path.

**Part G — Canonical Quantization.** Bridges classical and quantum
mechanics. Starting from the classical harmonic oscillator Lagrangian
$L = \frac{1}{2}m\dot{x}^2 - \frac{1}{2}m\omega^2 x^2$, promotes
$\{x, p\} = 1$ to $[\hat{x}, \hat{p}] = i\hbar$, and solves the
resulting Schrödinger equation with `DSolve`. Verifies that the
eigenvalues are $E_n = \omega(n + \frac{1}{2})$ by direct substitution
of Hermite–Gauss wavefunctions for $n = 0, \ldots, 5$.

### Key Library Functions (qm_postulates.wls)

| Function | Purpose |
|---|---|
| `QState`, `QBra`, `QInnerProduct` | Ket/bra algebra, inner products |
| `QExpectation`, `QVariance` | Observable statistics |
| `QCommutator`, `QAntiCommutator` | Algebraic operations |
| `QMeasurementProbabilities` | Born rule implementation |
| `QTimeEvolve` | Propagator $U(t) = e^{-iHt}$ |
| `QTensorProduct`, `QDensityMatrix`, `QPartialTrace` | Composite systems |
| `QPauliX/Y/Z`, `QIdentity` | Standard operators |

---

## 3. Cycle 2: Simple Quantum Systems

### Research and Implementation

Cycle 2 addressed Sub-Topic 2 — the canonical exactly-solvable systems
that form the core of introductory quantum mechanics. The worker
produced:

- **Library `qm_systems.wls`** (201 lines, 16 functions) covering
  potentials, eigensolvers, wavefunction operations, ladder operators,
  and a numerical finite-difference eigensolver.
- **Exploration script `qm_foundations_02_simple_systems.wls`** (976
  lines, 5 parts).
- **Test suite `test_qm_systems.wls`** (28 assertions across 6
  categories).

### Physics Content

**Part A — The Infinite Square Well.** Solves $-\frac{1}{2}\psi''(x) =
E\psi(x)$ on $[0, L]$ with Dirichlet boundary conditions using `DSolve`.
The boundary condition $\psi(L) = 0$ enforces quantization: $E_n =
n^2\pi^2/(2L^2)$. Verifies orthonormality $\langle m|n\rangle =
\delta_{mn}$ via numerical integration for $n, m = 1, \ldots, 5$.
Demonstrates Fourier expansion of an arbitrary initial state in the
eigenbasis and time evolution via $e^{-iE_n t}$ phase factors, including
the quantum revival time $T_{\text{rev}} = 4mL^2/(\pi\hbar)$ at which
the wavefunction reconstructs. Cross-validates analytic eigenvalues
against the numerical eigensolver (`QNumericalEigensolve`).

**Part B — The Harmonic Oscillator.** Constructs the ladder operators
$\hat{a}$ and $\hat{a}^\dagger$ in a truncated Fock basis using sparse
matrices. Verifies $[\hat{a}, \hat{a}^\dagger] = I$ (in the interior
of the truncated basis), $[\hat{N}, \hat{a}] = -\hat{a}$, and
$[\hat{N}, \hat{a}^\dagger] = \hat{a}^\dagger$. Demonstrates the ladder
action: $\hat{a}|0\rangle = 0$ (vacuum annihilation), $\hat{a}|n\rangle
= \sqrt{n}|n-1\rangle$, $\hat{a}^\dagger|n\rangle =
\sqrt{n+1}|n+1\rangle$. Constructs position and momentum operators
$\hat{x} = (\hat{a} + \hat{a}^\dagger)/\sqrt{2}$, $\hat{p} =
i(\hat{a}^\dagger - \hat{a})/\sqrt{2}$ and verifies $\Delta x \cdot
\Delta p = n + \frac{1}{2}$ for $n = 0, \ldots, 6$, showing that the
uncertainty principle is saturated only for the ground state.

**Part C — Coherent States.** Constructs coherent states $|\alpha\rangle
= e^{-|\alpha|^2/2}\sum_n \frac{\alpha^n}{\sqrt{n!}}|n\rangle$ and
verifies the eigenvalue equation $\hat{a}|\alpha\rangle =
\alpha|\alpha\rangle$. Demonstrates Poisson photon number distribution
$P(n) = e^{-|\alpha|^2}|\alpha|^{2n}/n!$. Verifies minimum uncertainty
$\Delta x \cdot \Delta p = \frac{1}{2}$ (the same as the vacuum).
Demonstrates Ehrenfest's theorem: the expectation values
$\langle\hat{x}\rangle(t)$ and $\langle\hat{p}\rangle(t)$ follow
classical trajectories.

**Part D — The Hydrogen Atom.** Separates the 3D Schrödinger equation in
spherical coordinates into angular (spherical harmonics $Y_l^m$) and
radial (associated Laguerre polynomials $R_{nl}$) parts. Displays
explicit $Y_l^m(\theta,\phi)$ for $l = 0, 1, 2$ and verifies
orthonormality via numerical integration. Computes energy levels $E_n =
-Z^2/(2n^2)$ in Hartree for $n = 1, \ldots, 5$ (converting to eV for
physical context). Verifies radial wavefunction normalization
$\int_0^\infty |R_{nl}(r)|^2 r^2\,dr = 1$ for six $(n, l)$ pairs and
orthogonality for states with the same $l$. Notes the $n^2$-fold
degeneracy as arising from the SO(4) dynamical symmetry (conserved
Runge–Lenz vector) and connects shell structure ($2n^2$ with spin) to
the periodic table.

**Part E — The Finite Well.** Solves the finite square well $V(x) =
-V_0$ for $|x| < a$, deriving the transcendental eigenvalue equations for
even and odd parity bound states. Demonstrates that the number of bound
states increases with $V_0 a^2$. Validates against the numerical
eigensolver and shows convergence to infinite-well eigenvalues as
$V_0 \to \infty$.

### Key Library Functions (qm_systems.wls)

| Function | Purpose |
|---|---|
| `QWellEigenstates`, `QHOEigenstates` | Exact eigensolvers |
| `QHydrogenRadial`, `QHydrogenEnergy` | Hydrogen atom |
| `QAnnihilationMatrix`, `QCreationMatrix`, `QNumberMatrix` | Ladder operators in Fock basis |
| `QCoherentState`, `QFockState` | Quantum state construction |
| `QNumericalEigensolve` | Finite-difference eigensolver |

---

## 4. Cycle 3: Spin and Angular Momentum

### Research and Implementation

Cycle 3 addressed Sub-Topic 3 — angular momentum as the representation
theory of the Lie algebra $\mathfrak{su}(2)$. The worker produced:

- **Library `qm_angular_momentum.wls`** (161 lines, 16 functions)
  covering angular momentum matrices, basis states, spin-$\frac{1}{2}$
  convenience functions, rotation operators, Clebsch–Gordan coefficients,
  and spin-orbit coupling.
- **Exploration script `qm_foundations_03_spin_angular_momentum.wls`**
  (798 lines, 5 parts).
- **Test suite `test_qm_angular_momentum.wls`** (39 assertions across 9
  categories).

### Physics Content

**Part A — The $\mathfrak{su}(2)$ Algebra and Its Representations.**
Constructs the angular momentum matrices $J_x$, $J_y$, $J_z$ for
$j = \frac{1}{2}, 1, \frac{3}{2}, 2$ using the ladder operator formula:
$J_+$ has superdiagonal elements $\sqrt{k(2j - k + 1)}$ at band
position $k$, encoding $\sqrt{j(j+1) - m(m+1)}$ via $m = j - k$.
Verifies all three commutation relations
$$[J_x, J_y] = iJ_z, \quad [J_y, J_z] = iJ_x, \quad [J_z, J_x] = iJ_y$$
for four values of $j$. Constructs the Casimir operator $J^2 = J_x^2 +
J_y^2 + J_z^2$ and verifies $J^2 = j(j+1)I$ for $j = \frac{1}{2},
1, \frac{3}{2}, 2, \frac{5}{2}$ (eigenvalues: $0.75, 2, 3.75, 6,
8.75$). Confirms $[J^2, J_i] = 0$ for all generators across four $j$
values — the Casimir commutes with every element of the algebra.

**Part B — Spin-$\frac{1}{2}$: The Fundamental Representation.**
Identifies $S_i = \sigma_i/2$ and verifies against `QJx/y/z[1/2]`.
Demonstrates:

- Arbitrary-axis measurement (eigenvalues always $\pm\frac{1}{2}$).
- Sequential Stern–Gerlach: measuring in incompatible bases destroys
  information.
- The $2\pi$ sign flip: $R(\hat{z}, 2\pi) = -I$ for half-integer $j$
  vs.\ $+I$ for integer $j$, with $|{\langle\psi|R(\hat{z},
  2\pi)|\psi\rangle}|^2 = 1$ verified to machine precision. This is the
  computational demonstration of the SU(2) $\to$ SO(3) double cover —
  a $2\pi$ rotation negates the spinor but leaves all probabilities
  invariant.
- Bloch sphere: computes $\langle \vec{S} \rangle$ for five spin states
  and verifies all point to correct locations with magnitude
  $\frac{1}{2}$.

**Part C — Orbital Angular Momentum and Spherical Harmonics.** Connects
the algebraic construction (matrices) to differential operators. Verifies
$$L_z Y_l^m = m Y_l^m$$
by explicit differentiation ($L_z = -i\partial/\partial\phi$) for $l =
0, \ldots, 3$ and all $m$ values (16 cases total). Verifies
$$L^2 Y_l^m = l(l+1) Y_l^m$$
for 8 representative $(l, m)$ pairs. Applies the raising operator $L_+
= e^{i\phi}(\partial_\theta + i\cot\theta\,\partial_\phi)$ to $Y_2^m$
for all five $m$ values. Explains the integer restriction on $l$: since
$Y_l^m \sim e^{im\phi}$, single-valuedness $Y(\theta, \phi + 2\pi) =
Y(\theta, \phi)$ forces $m$ (and hence $l$) to be integer. Spin can be
half-integer because spinors are not functions of spatial angles. Verifies
parity $Y_l^m(\pi - \theta, \phi + \pi) = (-1)^l Y_l^m(\theta, \phi)$
for $l = 1, \ldots, 4$.

**Part D — Addition of Angular Momenta.** Demonstrates the
Clebsch–Gordan decomposition for two cases:

- $\frac{1}{2} \otimes \frac{1}{2} = 0 \oplus 1$ (singlet + triplet):
  the 4-dimensional product space decomposes into a 1-dimensional $J=0$
  subspace and a 3-dimensional $J=1$ subspace.
- $1 \otimes 1 = 0 \oplus 1 \oplus 2$: the 9-dimensional product space
  decomposes into three irreducible subspaces.

Constructs the Clebsch–Gordan unitary matrix $U$ via
`QCouplingTransform`, verifies unitarity ($U^\dagger U = I$), and
confirms that $U$ block-diagonalizes $J^2_{\text{total}}$:
$\text{diag}(2,2,2,0)$ for $\frac{1}{2} \otimes \frac{1}{2}$ and
$\text{diag}(6,6,6,6,6,2,2,2,0)$ for $1 \otimes 1$ (to
$\sim\!10^{-15}$). Verifies the dimension formula
$(2j_1+1)(2j_2+1) = \sum_{J=|j_1-j_2|}^{j_1+j_2}(2J+1)$ for 8
$(j_1, j_2)$ pairs. Demonstrates the triangle rule and $M$ selection
rule ($M = m_1 + m_2$).

**Part E — Spin-Orbit Coupling.** Constructs $\vec{L} \cdot \vec{S} =
L_x \otimes S_x + L_y \otimes S_y + L_z \otimes S_z$ as explicit
matrices using Kronecker products: a $6 \times 6$ matrix for $l=1$,
$s=\frac{1}{2}$ (hydrogen 2p) and a $10 \times 10$ matrix for $l=2$,
$s=\frac{1}{2}$ (hydrogen 3d). Eigenvalues match the formula
$$\langle \vec{L} \cdot \vec{S} \rangle =
\frac{j(j+1) - l(l+1) - s(s+1)}{2}$$
exactly:

| System | $j$ values | $\vec{L}\cdot\vec{S}$ eigenvalues | Multiplicities |
|---|---|---|---|
| 2p ($l=1$) | $\frac{3}{2}, \frac{1}{2}$ | $+\frac{1}{2}, -1$ | 4, 2 |
| 3d ($l=2$) | $\frac{5}{2}, \frac{3}{2}$ | $+1, -\frac{3}{2}$ | 6, 4 |

The CG transform perfectly diagonalizes $\vec{L}\cdot\vec{S}$
(off-diagonal maximum = 0). Verifies the Landé interval rule: the
energy splitting between adjacent $j$ levels satisfies
$\Delta E / j_{\text{upper}} = 1$ for $l = 1, \ldots, 4$. Computes
the fine structure ratio $\Delta E(2p) / \Delta E(3d) = 162/16 =
10.125$, confirming the $n^{-3}$ scaling.

### Key Library Functions (qm_angular_momentum.wls)

| Function | Purpose |
|---|---|
| `QJz`, `QJPlus`, `QJMinus`, `QJx`, `QJy` | Angular momentum matrices for arbitrary $j$ |
| `QJSquared` | Casimir operator $J^2 = j(j+1)I$ |
| `QSpinState`, `QSpinOperator` | Spin-$\frac{1}{2}$ convenience |
| `QRotation`, `QRotationEuler` | Rotation operators via $e^{-i\theta \hat{n}\cdot\vec{J}}$ |
| `QClebschGordan`, `QCoupledBasisState`, `QCouplingTransform` | Angular momentum coupling |
| `QSpinOrbit` | $\vec{L}\cdot\vec{S}$ operator |

---

## 5. Cycle 4: The Measurement Problem (In Progress)

Cycle 4 initiated Sub-Topic 4 — the measurement problem. A researcher
session produced an exploration brief, but no worker or auditor sessions
have been created. The audit report from Cycle 3 recommended proceeding
to Sub-Topic 4 with the following guidance:

- The measurement problem is primarily conceptual/interpretational but
  can be given computational content through decoherence models, pointer
  states, and the quantum-to-classical transition.
- The density matrix formalism (Sub-Topic 8) is closely related; the
  measurement problem motivates mixed states and partial traces.
- Existing tools from Cycle 1 (`QDensityMatrix`, `QPartialTrace`) and
  the Bell state partial trace result (pure $\to$ mixed via tracing)
  provide the computational seed for decoherence analysis.
- Spin-$\frac{1}{2}$ states and rotation operators from Cycle 3 provide
  natural measurement scenarios (Stern–Gerlach sequences).

---

## 6. Validation Summary

The audit for Cycle 3 also served as a cumulative validation of all
three sub-topics. Results:

**Test Results:** 99/99 assertions pass (32 + 28 + 39) across three
test suites. All three exploration scripts execute correctly end-to-end.

**Physics Results Verified:**

| Result | Method | Status |
|---|---|---|
| $[\sigma_i, \sigma_j] = 2i\varepsilon_{ijk}\sigma_k$ | Matrix algebra | Pass |
| $[J_x, J_y] = iJ_z$ for $j = \frac{1}{2}, 1, \frac{3}{2}, 2$ | Matrix commutator | Pass |
| $J^2 = j(j+1)I$ for $j = \frac{1}{2}$ through $\frac{5}{2}$ | Eigenvalue computation | Pass |
| $E_n = n^2\pi^2/(2L^2)$ (infinite well) | `DSolve` + numerical | Pass |
| $E_n = \omega(n + \frac{1}{2})$ (harmonic oscillator) | Hermite–Gauss substitution | Pass |
| $\hat{a}|\alpha\rangle = \alpha|\alpha\rangle$ (coherent states) | Fock basis expansion | Pass |
| $E_n = -Z^2/(2n^2)$ (hydrogen) | Laguerre polynomials | Pass |
| $L_z Y_l^m = m Y_l^m$ (16 cases) | Differential operator | Pass |
| $R(\hat{z}, 2\pi) = -I$ for half-integer $j$ | `MatrixExp` | Pass |
| CG unitarity ($U^\dagger U = I$) | Exact arithmetic | Pass |
| $\vec{L}\cdot\vec{S}$ eigenvalues match $(J^2-L^2-S^2)/2$ | Kronecker product + diagonalization | Pass |
| Landé interval rule ($\Delta E / j_{\text{upper}} = 1$) | Algebraic formula | Pass |
| Fine structure ratio $\Delta E(2p)/\Delta E(3d) = 10.125$ | Analytic | Pass |

**Minor Issues Logged (4):**

1. Unusual comparison pattern `c1 == 0 c1` in exploration script —
   functionally correct but unconventional Wolfram idiom.
2. $L^2$ verification covers a subset of $m$ values per $l$ (adequate
   by representation theory, since $L^2$ acts as a scalar on each
   irreducible subspace).
3. Wigner–Eckart theorem not implemented — deferred to a dedicated
   symmetry sub-topic (Sub-Topic 9).
4. `QRotationEuler` implemented but not exercised in tests or
   exploration — low risk since it composes `MatrixExp` calls tested
   via `QRotation`.

No critical or moderate issues were found.

---

## 7. Cross-Cutting Connections

The audit report identified a deliberate pedagogical arc across the three
cycles: **algebraic $\to$ differential $\to$ algebraic**.

- **Cycle 1** established matrix/finite-dimensional quantum mechanics
  (operators as matrices, states as vectors).
- **Cycle 2** transitioned to differential operators and wave mechanics
  (Schrödinger equation, wavefunctions, continuous spectra).
- **Cycle 3** returned to algebra (SU(2) representation theory) but
  connected it to both the matrix and differential frameworks.

Specific connections between sub-topics:

| Cycle 1 Concept | Cycle 3 Connection |
|---|---|
| Pauli matrices $\sigma_i$ | Spin-$\frac{1}{2}$ generators $S_i = \sigma_i / 2$ |
| Tensor product $\otimes$ | Angular momentum coupling via CG coefficients |
| Partial trace (Bell states $\to$ mixed) | Seed for decoherence analysis (Cycle 4) |

| Cycle 2 Concept | Cycle 3 Connection |
|---|---|
| Ladder operators $\hat{a}, \hat{a}^\dagger$ | Angular momentum raising/lowering $J_\pm$ |
| Spherical harmonics $Y_l^m$ | Orbital angular momentum eigenstates |
| Hydrogen separation of variables | Spin-orbit coupling of radial and angular parts |

This completes a "three views of QM" foundation: matrix mechanics,
wave mechanics, and algebraic (group-theoretic) methods, with explicit
bridges between all three.

---

## 8. Open Items

1. **Sub-Topic 4 (The Measurement Problem):** Research brief produced;
   implementation pending.
2. **Wigner–Eckart theorem:** Identified as relevant to angular momentum
   but deferred to Sub-Topic 9 (symmetry).
3. **`QRotationEuler`:** Implemented but not tested or demonstrated.
   The underlying `MatrixExp` machinery is tested via `QRotation`, so
   correctness risk is minimal.
4. **Git tracking:** The `quantum_foundations/` directory is currently
   untracked in the repository (not committed). All four prior commits
   in `wolfram-bridge` predate the quantum foundations work.
5. **Remaining sub-topics:** The overall exploration plan includes at
   least 9 sub-topics. Sub-Topics 4–9+ remain to be explored. The
   next recommended sub-topic is the measurement problem, with density
   matrices (Sub-Topic 8) as a closely related follow-up.

---

## 9. Gaps in Record

- **Session database inaccessible.** The session summaries for all 10
  cycle sessions (3 researchers, 3 workers, 3 auditors, 1 Cycle-4
  researcher) could not be retrieved directly. The report is
  reconstructed from code artifacts and the provided audit report.
  Individual researcher briefs and auditor deliberations for Cycles 1
  and 2 are not reflected in detail — only their outputs (the code and
  the cumulative audit) are available.
- **Cycle 4 researcher brief content.** The research brief for Sub-Topic
  4 was produced in session `0358706d` but its content is not available
  for this report. The audit report's guidance notes (Section 5 above)
  are the only record of planned Cycle 4 scope.
- **Cycle 1 and 2 individual audit reports.** The provided audit report
  covers Cycle 3 but includes cumulative progress notes referencing
  "Sub-Topics 1–3 complete" with aggregate test counts ("30+26+37").
  Individual audit verdicts for Cycles 1 and 2 are not separately
  available, though the cumulative pass implies they were validated.
